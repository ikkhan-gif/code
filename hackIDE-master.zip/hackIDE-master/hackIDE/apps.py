#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: sahildua2305
# @Date:   2016-01-06 00:11:27
# @Last Modified by:   sahildua2305
# @Last Modified time: 2016-01-07 02:28:52


from django.apps import AppConfig


class HackideConfig(AppConfig):
    name = 'hackIDE'
